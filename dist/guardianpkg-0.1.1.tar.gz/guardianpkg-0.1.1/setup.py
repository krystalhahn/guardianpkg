# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['guardianpkg']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib>=3.6.2,<4.0.0',
 'pandas>=1.5.2,<2.0.0',
 'requests>=2.28.1,<3.0.0',
 'seaborn>=0.12.1,<0.13.0',
 'sphinx>=5.3.0,<6.0.0']

setup_kwargs = {
    'name': 'guardianpkg',
    'version': '0.1.1',
    'description': 'Python package that acquires data from The Guardian API and includes functions that can seararch and plot results!',
    'long_description': '# guardianpkg\n\nPython package that acquires data from The Guardian API and includes functions that can search and plot results!\n\n## Installation\n\n```bash\n$ pip install guardianpkg\n```\n\n## Usage\n\n- TODO\n\n## Contributing\n\nInterested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.\n\n## License\n\n`guardianpkg` was created by Krystal Hahn. It is licensed under the terms of the MIT license.\n\n## Credits\n\n`guardianpkg` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).\n',
    'author': 'Krystal Hahn',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
