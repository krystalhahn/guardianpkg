# guardianpkg

Python package that acquires data from The Guardian API and includes functions that can search and plot results!

## Installation

```bash
$ pip install guardianpkg
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`guardianpkg` was created by Krystal Hahn. It is licensed under the terms of the MIT license.

## Credits

`guardianpkg` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
